# Movie Recommender system

you can find similarity pkl one here in the link
https://drive.google.com/file/d/1bzWrkdvlyKbhB-nw6itEtMzX2m49Xqcg/view?usp=sharing

# Steps to open 
-> install pycharm and make new file as app.py and copy the code in that <br>
And put similarity.pkl in the same folder<br>
And open terminal write "streamlit run app.py"
